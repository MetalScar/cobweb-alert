package com.cobwebalert;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.minecraft.block.Blocks;
import net.minecraft.item.Items;

/**
 * Cobweb Alert Mod - Client Entry Point
 *
 * How it works in one sentence:
 *   Every tick we scan nearby entities; any cobweb that overlaps a living entity
 *   gets registered as "active", and Fabric's colour-provider system makes those
 *   cobwebs render red instead of white.
 *
 * This is 100% client-side. It reads only data that every Minecraft client already
 * receives normally in multiplayer, so it works on any server without a server-side
 * install. Every player who has the mod sees ALL occupied cobwebs highlighted,
 * not just the ones they are personally inside.
 */
public class CobwebAlertClient implements ClientModInitializer {

    // The red tint applied to occupied cobwebs.
    // Change this hex value to any RGB colour you want (e.g. 0xFF8000 for orange).
    static final int ALERT_COLOR  = 0xFF2222;

    // White (0xFFFFFF) = "no tint" = vanilla appearance for unoccupied cobwebs.
    static final int NORMAL_COLOR = 0xFFFFFF;

    @Override
    public void onInitializeClient() {

        // --- Block colour provider ---
        // Fabric calls this lambda every time a cobweb block face is about to be
        // rendered. We simply check our live "active positions" set and return
        // the appropriate colour. pos is null during inventory/item rendering,
        // hence the null-check.
        ColorProviderRegistry.BLOCK.register(
                (state, world, pos, tintIndex) ->
                        (pos != null && CobwebTracker.isActive(pos))
                                ? ALERT_COLOR
                                : NORMAL_COLOR,
                Blocks.COBWEB
        );

        // --- Item colour provider ---
        // Keeps the cobweb item (held, in inventory, dropped on ground) untinted
        // so it still looks normal white everywhere outside the world.
        ColorProviderRegistry.ITEM.register(
                (stack, tintIndex) -> NORMAL_COLOR,
                Items.COBWEB
        );

        // --- Per-tick scan ---
        // Runs after every client game tick (20×/second).
        // CobwebTracker.tick() re-checks all entity positions and schedules
        // chunk re-renders for any cobweb whose "active" state just changed.
        ClientTickEvents.END_CLIENT_TICK.register(CobwebTracker::tick);
    }
}
