package com.cobwebalert;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkSectionPos;

import java.util.HashSet;
import java.util.Set;

/**
 * Maintains the live set of cobweb block positions that currently have at least
 * one living entity (player, mob, etc.) overlapping them.
 *
 * This class is called once per client tick. It works by:
 *   1. Iterating every entity currently loaded in the client world.
 *   2. For any LivingEntity, iterating the block positions inside its bounding box.
 *   3. If that block is a cobweb, marking it active.
 *   4. Comparing the new set to the previous set - for any position that changed
 *      state (became active OR became inactive), telling the world renderer to
 *      redraw that chunk section so the new colour appears immediately.
 */
public final class CobwebTracker {

    // The set of cobweb positions that currently have an entity inside them.
    // Swapped out wholesale every tick (cheap - usually very small).
    private static volatile Set<BlockPos> activePosSet = new HashSet<>();

    private CobwebTracker() {}

    /** Called by the colour provider to decide the tint for a specific cobweb. */
    public static boolean isActive(BlockPos pos) {
        return activePosSet.contains(pos);
    }

    /** Called once per client tick from CobwebAlertClient. */
    public static void tick(MinecraftClient client) {
        if (client.world == null) {
            activePosSet = new HashSet<>();
            return;
        }

        Set<BlockPos> newActive = new HashSet<>();

        for (Entity entity : client.world.getEntities()) {
            // Only care about living entities (players, mobs).
            // Arrows, dropped items, falling blocks, etc. are skipped.
            if (!(entity instanceof LivingEntity)) continue;

            Box box = entity.getBoundingBox();

            // Iterate every block position the entity's bounding box overlaps.
            BlockPos min = BlockPos.ofFloored(box.minX, box.minY, box.minZ);
            BlockPos max = BlockPos.ofFloored(box.maxX, box.maxY, box.maxZ);

            for (BlockPos.Mutable cursor = new BlockPos.Mutable();; ) {
                // Manual triple loop is faster than BlockPos.iterate() for small ranges
                // and avoids the allocation of the Iterable wrapper.
                for (int x = min.getX(); x <= max.getX(); x++) {
                    for (int y = min.getY(); y <= max.getY(); y++) {
                        for (int z = min.getZ(); z <= max.getZ(); z++) {
                            cursor.set(x, y, z);
                            if (client.world.getBlockState(cursor).isOf(Blocks.COBWEB)) {
                                // toImmutable() is essential here: cursor is reused
                                // every iteration so we must snapshot it before storing.
                                newActive.add(cursor.toImmutable());
                            }
                        }
                    }
                }
                break; // single-pass outer loop used only for the break label
            }
        }

        Set<BlockPos> previous = activePosSet;
        activePosSet = newActive;

        // Schedule re-renders only for cobwebs whose state actually changed.
        // This avoids triggering a full chunk rebuild every tick.
        for (BlockPos pos : newActive) {
            if (!previous.contains(pos)) scheduleRerender(client, pos);
        }
        for (BlockPos pos : previous) {
            if (!newActive.contains(pos)) scheduleRerender(client, pos);
        }
    }

    /**
     * Tells the world renderer that the chunk section containing this position
     * needs to be rebuilt on the next frame.
     *
     * The method name used here (scheduleBlockRenders) is the correct name under
     * Mojang mappings for 1.21.11. If IntelliJ ever shows it underlined in red
     * after a version bump, place your cursor after "worldRenderer." and press
     * Ctrl+Space - look for a method taking three ints related to "schedule" or
     * "render" and select that.
     */
    private static void scheduleRerender(MinecraftClient client, BlockPos pos) {
        if (client.worldRenderer == null) return;
        client.worldRenderer.scheduleBlockRenders(
                ChunkSectionPos.getSectionCoord(pos.getX()),
                ChunkSectionPos.getSectionCoord(pos.getY()),
                ChunkSectionPos.getSectionCoord(pos.getZ())
        );
    }
}
